function changeBlue(){
    const ele = document.getElementById("image");
    const newurl = "https://lh3.googleusercontent.com/proxy/BsLrZ0GXLktKO3KXwejuNcRrupBdUhRR5eMuvAneJ1CcfxYSPx0g9wtG4d-494FUehqq1XlHRxQBFWnLKuA_iQhu8Ch5UnxPJUeZY7LR8VKlmpDJkBq569ECWT_NeZ_qFrqPzIN1lA";
    ele.src = newurl;
}

function changePurple(){
    const ele = document.getElementById("image");
    const newurl = "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR0Z_by00W9OReqLS6ZasmQ3oZlRgKaHKvhbg&usqp=CAU";
    ele.src = newurl;
}

function changeRed(){
    const ele = document.getElementById("image");
    const newurl = "https://r1.ilikewallpaper.net/iphone-11-wallpapers/download/79386/flower-iphone-11-wallpaper-ilikewallpaper_com.jpg";
    ele.src = newurl;
}
