function printName(){
    const ele = document.getElementsByClassName("name");
    ele[1].value = ele[0].value;
}